import { useId, type CSSProperties, type ReactNode } from 'react'
import { colors } from '@/design/tokens'
import { ClaySvg } from '../art'
import { Slab, drop, lift, useFx } from '../clay-a'
import { Shadow } from '../depth'
import { LAB } from '../d3/kit'
import type { CharacterConfig } from '../cast/skins/config'

/**
 * THE ROOMS AND THEIR FURNITURE (review 2026-10-29: "every analogy scene must
 * be built as illustration elements that look like their real-life
 * counterparts ... each scene must include a visible environment").
 *
 * Front-facing objects in session 1's clay finish (a lit top, a graded front,
 * a specular on the upper left, a blurred cool shadow under the base), drawn
 * so each one is recognisable on its own: an oven has a glass door with a
 * handle, a knob panel, a rack and a tray inside; a counter has drawers and
 * legs; a table has a cloth, chairs and a centrepiece. `Room` is the
 * environment every scene stands in: a wall over a floor inside one rounded
 * plate, tiled for a kitchen, panelled for a hall, bare for an empty shell.
 * Labels stay HTML in the scenes; nothing here draws text.
 */

const EASE = 'cubic-bezier(0.22,1,0.36,1)'
/** the customer's amber, `ISO.customer` */
export const AMBER = '#F5A623'
const STEEL = '#B9C4D8'
const STEEL_DK = '#7F8CA8'
const STEEL_LT = '#E6EBF5'
const CHARCOAL = LAB.charcoal
const GOLD = '#D9A441'
const WIRE = '#5A6378'

/* ------------------------------------------------------------------ the environment */

export type RoomKind = 'kitchen' | 'hall' | 'shell'

/**
 * A room: a wall over a floor, inside one rounded plate the size of the
 * scene's site. `kitchen` is white tiles over a chequered floor, `hall` a
 * warm wall with a panelled dado over a plank floor, `shell` a bare concrete
 * wall over a bare screed floor. `lit` rings the plate in brand blue (the site
 * that has just taken work, as `Zone` does), `dim` fades it.
 */
export function Room({ x, y, w, h, kind = 'kitchen', floorAt = 0.68, lit = false, dim = false }: { x: number; y: number; w: number; h: number; kind?: RoomKind; floorAt?: number; lit?: boolean; dim?: boolean }) {
  const id = useId().replace(/:/g, '')
  const fy = Math.round(h * floorAt)
  const wallFill = kind === 'kitchen' ? `url(#${id}-tile)` : kind === 'hall' ? '#F7F2EA' : '#E4E7EE'
  const floorFill = kind === 'kitchen' ? `url(#${id}-chk)` : kind === 'hall' ? `url(#${id}-plank)` : '#CDD3DE'
  /* the rim is drawn inside the svg, not as an inset ring: the overlap harness reads a ringed div as a box
     and every drawn object inside it as an arrow over that box; the plate's own shadow stays on the div */
  const shade = lit ? '0 14px 28px -16px rgba(45,99,251,0.45)' : '0 12px 24px -18px rgba(31,64,140,0.4)'
  return (
    <div aria-hidden className="pointer-events-none absolute overflow-hidden rounded-[16px]" style={{ left: x, top: y, width: w, height: h, boxShadow: shade, opacity: dim ? 0.55 : 1, transition: `box-shadow 420ms ${EASE}, opacity 420ms ${EASE}` }}>
      <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} style={{ display: 'block' }}>
        <defs>
          <pattern id={`${id}-tile`} width="28" height="20" patternUnits="userSpaceOnUse">
            <rect width="28" height="20" fill="#F3F7FD" />
            <path d="M 0 10 H 28 M 14 0 V 10 M 0 10 V 20 M 28 10 V 20" fill="none" stroke={LAB.lavender} strokeWidth={1.2} />
            <path d="M 0 0 H 28 M 0 20 H 28" fill="none" stroke={LAB.lavender} strokeWidth={1.2} />
          </pattern>
          <pattern id={`${id}-chk`} width="24" height="24" patternUnits="userSpaceOnUse">
            <rect width="24" height="24" fill="#D9E0EC" />
            <rect width="12" height="12" fill="#E6EBF4" />
            <rect x="12" y="12" width="12" height="12" fill="#E6EBF4" />
          </pattern>
          <pattern id={`${id}-plank`} width="46" height="12" patternUnits="userSpaceOnUse">
            <rect width="46" height="12" fill="#DDB98F" />
            <path d="M 0 11.5 H 46 M 23 0 V 6 M 0 6 H 46" fill="none" stroke="#C99D6E" strokeWidth={1} />
          </pattern>
          <linearGradient id={`${id}-floorShade`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#000000" stopOpacity={0.1} />
            <stop offset="1" stopColor="#000000" stopOpacity={0} />
          </linearGradient>
        </defs>
        <rect x={0} y={0} width={w} height={fy} fill={wallFill} />
        {kind === 'hall' && (
          <g>
            {/* the dado: a panelled band at the foot of the wall, a rail above it */}
            <rect x={0} y={fy - 26} width={w} height={26} fill="#EADFCD" />
            <rect x={0} y={fy - 28} width={w} height={3} fill="#D6C6AE" />
            {Array.from({ length: Math.ceil(w / 40) }, (_, i) => (
              <rect key={i} x={i * 40 + 6} y={fy - 21} width={28} height={16} rx={2} fill="none" stroke="#D6C6AE" strokeWidth={1.2} />
            ))}
          </g>
        )}
        {kind === 'shell' && (
          <g>
            {/* a bare wall: a few hairline seams and a skirting that is just plaster */}
            {[0.3, 0.62].map((k) => (
              <rect key={k} x={0} y={fy * k} width={w} height={1.2} fill="#D5D9E2" />
            ))}
            <rect x={0} y={fy - 6} width={w} height={6} fill="#D7DBE4" />
          </g>
        )}
        {kind === 'kitchen' && <rect x={0} y={fy - 5} width={w} height={5} fill={STEEL_DK} opacity={0.6} />}
        <rect x={0} y={fy} width={w} height={h - fy} fill={floorFill} />
        <rect x={0} y={fy} width={w} height={Math.min(18, h - fy)} fill={`url(#${id}-floorShade)`} />
        <rect x={0.5} y={0.5} width={w - 1} height={h - 1} rx={15.5} fill="none" stroke="rgba(31,64,140,0.14)" strokeWidth={1} />
        <rect x={1} y={1} width={w - 2} height={h - 2} rx={15} fill="none" stroke={colors.brand} strokeWidth={2} style={{ opacity: lit ? 1 : 0, transition: `opacity 420ms ${EASE}` }} />
      </svg>
    </div>
  )
}

/** An object placed by its bottom centre, so a row of things shares one ground line; `style` goes on an inner div, so the anchor stays. */
export function Stand({ x, b, children, style }: { x: number; b: number; children: ReactNode; style?: CSSProperties }) {
  return (
    <div className="absolute" style={{ left: x, top: b, transform: 'translate(-50%, -100%)' }}>
      <div style={style}>{children}</div>
    </div>
  )
}

/* ------------------------------------------------------------------ kitchen equipment */

/**
 * An oven, the real thing: a steel body on two feet, a knob panel with a
 * display across the top, and under it a door with a bar handle and a glass
 * window; through the glass a rack with a tray on it, and the inside glows
 * warm while it bakes. `double` stacks two doors (a commercial double oven).
 */
export function RealOven({ w, on, double = false }: { w: number; on: boolean; double?: boolean }) {
  const fx = useFx({ body: STEEL, panel: STEEL_DK, glass: CHARCOAL, warm: LAB.orange, handle: STEEL_LT })
  const doors = double ? 2 : 1
  const DH = 62
  const vh = 36 + doors * DH + 10
  return (
    <ClaySvg w={w} vw={100} vh={vh}>
      {fx.defs}
      <Shadow id={fx.id} cx={50} cy={vh - 2} rx={44} ry={4} o={0.24} />
      <rect x={12} y={vh - 11} width={12} height={7} rx={2} fill={drop(STEEL_DK, 0.25)} />
      <rect x={76} y={vh - 11} width={12} height={7} rx={2} fill={drop(STEEL_DK, 0.25)} />
      <Slab x={4} y={6} w={92} h={vh - 17} rx={8} d={6} hue={STEEL} fill={fx.g('body')} />
      {/* the control panel: three knobs with their pointers, a display */}
      <path d="M 4 14 a 8 8 0 0 1 8 -8 H 88 a 8 8 0 0 1 8 8 V 32 H 4 Z" fill={fx.g('panel')} />
      {[20, 36, 52].map((cx) => (
        <g key={cx}>
          <circle cx={cx} cy={19} r={5.2} fill={STEEL_LT} />
          <circle cx={cx} cy={19} r={5.2} fill="none" stroke={drop(STEEL_DK, 0.35)} strokeWidth={1} />
          <rect x={cx - 0.9} y={14.2} width={1.8} height={4.6} rx={0.9} fill={CHARCOAL} />
        </g>
      ))}
      <rect x={66} y={13} width={24} height={12} rx={2} fill={LAB.navy} />
      <rect x={69} y={16} width={12} height={6} rx={1} fill={on ? LAB.green : '#7A86A8'} style={{ transition: `fill 420ms ${EASE}` }} />
      {Array.from({ length: doors }, (_, i) => {
        const y = 38 + i * DH
        return (
          <g key={i}>
            {/* the bar handle, its two mounts */}
            <rect x={14} y={y} width={72} height={6.5} rx={3.2} fill={fx.g('handle')} />
            <rect x={14} y={y} width={7} height={6.5} rx={2} fill={drop(STEEL_DK, 0.2)} />
            <rect x={79} y={y} width={7} height={6.5} rx={2} fill={drop(STEEL_DK, 0.2)} />
            {/* the door and its glass */}
            <rect x={10} y={y + 11} width={80} height={DH - 15} rx={5} fill={drop(STEEL, 0.1)} />
            <rect x={16} y={y + 16} width={68} height={DH - 25} rx={4} fill={fx.g('glass')} />
            <rect x={16} y={y + 16} width={68} height={DH - 25} rx={4} fill={fx.g('warm')} style={{ opacity: on ? 0.9 : 0, transition: `opacity 520ms ${EASE}` }} />
            {/* the rack inside, a tray on it */}
            <path d={`M 20 ${y + 32} H 80 M 20 ${y + 44} H 80`} stroke={on ? '#FFE3B5' : '#8F9BBA'} strokeWidth={1.6} />
            {[24, 36, 48, 60, 72].map((x) => (
              <rect key={x} x={x} y={y + 32} width={1.4} height={4} fill={on ? '#FFE3B5' : '#8F9BBA'} />
            ))}
            <rect x={34} y={y + 27} width={32} height={5.5} rx={2} fill={on ? '#FFD28A' : '#6C7AA0'} />
            <path d={`M 18 ${y + 21} L 46 ${y + 18} L 18 ${y + 42} Z`} fill="#FFFFFF" opacity={0.16} />
          </g>
        )
      })}
    </ClaySvg>
  )
}

/** A stainless-steel counter: a lit top, two drawers and a door with pull handles, a shelf under, four legs. */
export function SteelCounter({ w }: { w: number }) {
  const fx = useFx({ top: STEEL_LT, body: STEEL, leg: STEEL_DK })
  return (
    <ClaySvg w={w} vw={160} vh={78}>
      {fx.defs}
      <Shadow id={fx.id} cx={80} cy={75} rx={72} ry={4} o={0.22} />
      {[14, 140].map((x) => (
        <rect key={x} x={x} y={58} width={6} height={16} rx={2} fill={fx.g('leg')} />
      ))}
      <rect x={12} y={55} width={136} height={5} rx={2} fill={fx.g('leg')} />
      <Slab x={8} y={22} w={144} h={34} rx={4} d={5} hue={STEEL} fill={fx.g('body')} />
      <rect x={14} y={27} width={60} height={11} rx={2} fill={drop(STEEL, 0.07)} />
      <rect x={14} y={41} width={60} height={11} rx={2} fill={drop(STEEL, 0.07)} />
      <rect x={34} y={31.5} width={20} height={2.6} rx={1.3} fill={STEEL_DK} />
      <rect x={34} y={45.5} width={20} height={2.6} rx={1.3} fill={STEEL_DK} />
      <rect x={80} y={27} width={64} height={25} rx={2} fill={drop(STEEL, 0.07)} />
      <rect x={85} y={34} width={2.6} height={12} rx={1.3} fill={STEEL_DK} />
      <Slab x={2} y={10} w={156} h={12} rx={3} d={5} hue={STEEL_LT} fill={fx.g('top')} />
      <rect x={8} y={12.5} width={90} height={2} rx={1} fill="#FFFFFF" opacity={0.75} />
    </ClaySvg>
  )
}

/** A rail on the wall with a ladle, a spatula, a whisk and a frying pan hanging from its hooks. */
export function UtensilRail({ w }: { w: number }) {
  const fx = useFx({ rail: STEEL_DK })
  const S = STEEL_DK
  return (
    <ClaySvg w={w} vw={120} vh={52}>
      {fx.defs}
      <rect x={6} y={2} width={6} height={10} rx={2} fill={WIRE} />
      <rect x={108} y={2} width={6} height={10} rx={2} fill={WIRE} />
      <rect x={2} y={8} width={116} height={4} rx={2} fill={fx.g('rail')} />
      {[26, 50, 74, 98].map((x) => (
        <path key={x} d={`M ${x} 12 v 4 a 3 3 0 0 0 6 0`} fill="none" stroke={WIRE} strokeWidth={1.6} />
      ))}
      {/* the ladle */}
      <rect x={30.7} y={16} width={2.6} height={22} rx={1.3} fill={S} />
      <path d="M 26 38 a 6 6 0 0 0 12 0 Z" fill={S} />
      {/* the spatula, a slotted blade */}
      <rect x={54.7} y={16} width={2.6} height={16} rx={1.3} fill={WIRE} />
      <rect x={50} y={31} width={12} height={15} rx={2} fill={S} />
      <path d="M 53 35 v 7 M 56 35 v 7 M 59 35 v 7" stroke={lift(S, 0.5)} strokeWidth={1} />
      {/* the whisk */}
      <rect x={78.7} y={16} width={2.6} height={12} rx={1.3} fill={WIRE} />
      <path d="M 80 28 c -7 6 -7 16 0 20 c 7 -4 7 -14 0 -20 M 80 28 c -3 6 -3 16 0 20 M 80 28 c 3 6 3 16 0 20" fill="none" stroke={S} strokeWidth={1.4} />
      {/* the frying pan, hung by its handle */}
      <rect x={102.7} y={16} width={2.6} height={13} rx={1.3} fill={WIRE} />
      <ellipse cx={104} cy={37} rx={9} ry={8} fill={CHARCOAL} />
      <ellipse cx={104} cy={36} rx={6.5} ry={5.5} fill={drop(CHARCOAL, 0.3)} />
    </ClaySvg>
  )
}

/** A cooking station: a steel cabinet with four knobs and two doors under a charcoal cooktop with four burners, a pot on one of them that steams while `on`. */
export function StoveStation({ w, on }: { w: number; on: boolean }) {
  const fx = useFx({ body: STEEL, top: CHARCOAL, pot: LAB.cobalt })
  return (
    <ClaySvg w={w} vw={110} vh={100}>
      {fx.defs}
      <Shadow id={fx.id} cx={55} cy={97} rx={50} ry={4} o={0.22} />
      <rect x={14} y={91} width={8} height={6} rx={2} fill={drop(STEEL_DK, 0.25)} />
      <rect x={88} y={91} width={8} height={6} rx={2} fill={drop(STEEL_DK, 0.25)} />
      <Slab x={6} y={50} w={98} h={43} rx={5} d={6} hue={STEEL} fill={fx.g('body')} />
      {[22, 38, 54, 70].map((cx) => (
        <g key={cx}>
          <circle cx={cx} cy={60} r={3.8} fill={STEEL_LT} stroke={drop(STEEL_DK, 0.3)} strokeWidth={0.8} />
          <rect x={cx - 0.8} y={56.6} width={1.6} height={3.4} fill={CHARCOAL} />
        </g>
      ))}
      <rect x={12} y={68} width={40} height={21} rx={2} fill={drop(STEEL, 0.07)} />
      <rect x={56} y={68} width={40} height={21} rx={2} fill={drop(STEEL, 0.07)} />
      <rect x={48} y={74} width={2.6} height={10} rx={1.3} fill={STEEL_DK} />
      <rect x={58} y={74} width={2.6} height={10} rx={1.3} fill={STEEL_DK} />
      <Slab x={2} y={40} w={106} h={11} rx={3} d={5} hue={CHARCOAL} fill={fx.g('top')} />
      {[20, 42, 64, 86].map((cx) => (
        <g key={cx}>
          <ellipse cx={cx} cy={42} rx={9} ry={3.6} fill="#1F2230" />
          <ellipse cx={cx} cy={42} rx={6} ry={2.3} fill="none" stroke="#7A86A8" strokeWidth={1} />
        </g>
      ))}
      {/* the flame under the pot, the pot, its lid and handles, the steam */}
      <ellipse cx={64} cy={43.5} rx={8} ry={2.2} fill={LAB.orange} style={{ opacity: on ? 0.95 : 0, transition: `opacity 420ms ${EASE}` }} />
      <rect x={50} y={27} width={28} height={17} rx={3} fill={fx.g('pot')} />
      <rect x={44} y={32} width={6} height={3} rx={1.5} fill={CHARCOAL} />
      <rect x={78} y={32} width={6} height={3} rx={1.5} fill={CHARCOAL} />
      <rect x={46} y={24.5} width={36} height={4.5} rx={2} fill={lift(LAB.cobalt, 0.3)} />
      <rect x={60} y={20} width={8} height={5} rx={2.5} fill={CHARCOAL} />
      <g data-flat style={{ opacity: on ? 1 : 0, transition: `opacity 420ms ${EASE}` }}>
        {[56, 64, 72].map((x, i) => (
          <path key={x} d={`M ${x} 18 c -3 -5 3 -8 0 -13 c -3 -5 3 -8 0 -5`} fill="none" stroke="#9AA6C4" strokeWidth={1.6} strokeLinecap="round" opacity={0.75 - i * 0.18} />
        ))}
      </g>
    </ClaySvg>
  )
}

/* ------------------------------------------------------------------ the hall and the dining room */

/**
 * A round table with a white cloth draped to the floor, a vase with one
 * flower, two laid plates and a glass; `chairs` puts a chair either side
 * behind it (the hall) or one chair centred behind it (a diner's seat).
 */
export function RoundTable({ w, chairs = 'sides' }: { w: number; chairs?: 'sides' | 'back' | 'none' }) {
  const fx = useFx({ cloth: '#F4F7FC', chair: LAB.wood })
  const chairAt = chairs === 'sides' ? [22, 108] : chairs === 'back' ? [65] : []
  return (
    <ClaySvg w={w} vw={130} vh={90}>
      {fx.defs}
      <Shadow id={fx.id} cx={65} cy={87} rx={52} ry={4} o={0.2} />
      {chairAt.map((cx) => (
        <g key={cx}>
          <rect x={cx - 11} y={14} width={22} height={28} rx={5} fill={fx.g('chair')} />
          <rect x={cx - 7} y={19} width={14} height={16} rx={3} fill={drop(LAB.wood, 0.1)} />
          <rect x={cx - 13} y={41} width={26} height={8} rx={2} fill={lift(LAB.wood, 0.12)} />
          <rect x={cx - 12} y={49} width={3} height={23} rx={1.5} fill={drop(LAB.wood, 0.25)} />
          <rect x={cx + 9} y={49} width={3} height={23} rx={1.5} fill={drop(LAB.wood, 0.25)} />
        </g>
      ))}
      <path d="M 17 44 V 70 q 6 6 12 0 q 6 6 12 0 q 6 6 12 0 q 6 6 12 0 q 6 6 12 0 q 6 6 12 0 q 6 6 12 0 q 6 6 12 0 V 44 Z" fill={fx.g('cloth')} />
      <ellipse cx={65} cy={44} rx={48} ry={13} fill="#FFFFFF" />
      <ellipse cx={65} cy={44} rx={48} ry={13} fill="none" stroke="#DCE4F3" strokeWidth={1} />
      <rect x={62} y={30} width={6} height={12} rx={2} fill={LAB.sky} />
      <circle cx={65} cy={27} r={4} fill={LAB.red} />
      <circle cx={65} cy={27} r={1.5} fill={LAB.yellow} />
      <ellipse cx={44} cy={46} rx={9} ry={3.5} fill={STEEL_LT} stroke="#C9D3E6" strokeWidth={1} />
      <ellipse cx={88} cy={46} rx={9} ry={3.5} fill={STEEL_LT} stroke="#C9D3E6" strokeWidth={1} />
      <rect x={98} y={35} width={5} height={9} rx={1.5} fill="#D3E1FB" opacity={0.9} />
    </ClaySvg>
  )
}

/** A chandelier on its chain: a gold body, two tiers of arms, five candle lamps with their flames and glow. */
export function Chandelier({ w, on = true }: { w: number; on?: boolean }) {
  const fx = useFx({ gold: GOLD })
  const CANDLES: [number, number][] = [[12, 44], [31, 38], [50, 28], [69, 38], [88, 44]]
  return (
    <ClaySvg w={w} vw={100} vh={64}>
      {fx.defs}
      <rect x={44} y={0} width={12} height={4} rx={2} fill={fx.g('gold')} />
      <rect x={49} y={3} width={2} height={14} fill={drop(GOLD, 0.2)} />
      <path d="M 12 44 Q 50 18 88 44" fill="none" stroke={fx.g('gold')} strokeWidth={3} strokeLinecap="round" />
      <path d="M 31 38 Q 50 24 69 38" fill="none" stroke={fx.g('gold')} strokeWidth={2.4} strokeLinecap="round" />
      <ellipse cx={50} cy={34} rx={6} ry={10} fill={fx.g('gold')} />
      <ellipse cx={50} cy={18} rx={5} ry={3.5} fill={fx.g('gold')} />
      {CANDLES.map(([x, y]) => (
        <g key={x}>
          <circle cx={x} cy={y - 14} r={9} fill={fx.gl('yellow')} style={{ opacity: on ? 0.9 : 0, transition: `opacity 420ms ${EASE}` }} />
          <rect x={x - 3.5} y={y - 4} width={7} height={5} rx={1.5} fill={fx.g('gold')} />
          <rect x={x - 2} y={y - 12} width={4} height={9} rx={1} fill="#FFF8E6" />
          <ellipse cx={x} cy={y - 14} rx={2.2} ry={3.2} fill={LAB.yellow} style={{ opacity: on ? 1 : 0.3, transition: `opacity 420ms ${EASE}` }} />
        </g>
      ))}
    </ClaySvg>
  )
}

/** A buffet table: a long white cloth to the floor, three steel chafing dishes with domed lids on it. */
export function BuffetTable({ w }: { w: number }) {
  const fx = useFx({ cloth: '#F4F7FC', dome: STEEL_LT, base: STEEL })
  return (
    <ClaySvg w={w} vw={150} vh={64}>
      {fx.defs}
      <Shadow id={fx.id} cx={75} cy={61} rx={70} ry={3.5} o={0.2} />
      <rect x={6} y={28} width={138} height={30} rx={3} fill={fx.g('cloth')} />
      <rect x={6} y={54} width={138} height={1.5} fill="#DCE4F3" />
      <rect x={2} y={24} width={146} height={7} rx={3} fill="#FFFFFF" />
      <rect x={2} y={24} width={146} height={7} rx={3} fill="none" stroke="#DCE4F3" strokeWidth={1} />
      {[28, 75, 122].map((cx) => (
        <g key={cx}>
          <rect x={cx - 17} y={18} width={34} height={7} rx={2} fill={fx.g('base')} />
          <path d={`M ${cx - 16} 18 a 16 13 0 0 1 32 0 Z`} fill={fx.g('dome')} />
          <path d={`M ${cx - 10} 12 q 6 -6 14 -4`} stroke="#FFFFFF" strokeWidth={1.5} fill="none" opacity={0.7} />
          <circle cx={cx} cy={5} r={2.2} fill={STEEL_DK} />
        </g>
      ))}
    </ClaySvg>
  )
}

/** A pendant lamp over a table: a cord, a shade and a lit bulb. */
export function PendantLamp({ w }: { w: number }) {
  const fx = useFx({ shade: LAB.navy })
  return (
    <ClaySvg w={w} vw={40} vh={60}>
      {fx.defs}
      <rect x={19} y={0} width={2} height={28} fill={WIRE} />
      <circle cx={20} cy={52} r={11} fill={fx.gl('yellow')} opacity={0.9} />
      <path d="M 6 46 L 12 28 H 28 L 34 46 Z" fill={fx.g('shade')} />
      <ellipse cx={20} cy={46} rx={14} ry={3} fill={drop(LAB.navy, 0.2)} />
      <circle cx={20} cy={48} r={4} fill={LAB.yellow} />
    </ClaySvg>
  )
}

/**
 * The kitchen pass: an opening in the dining-room wall with a steel frame,
 * a counter sill at its foot and two heat lamps hung over it; whatever is
 * inside (the chef at the stove) is seen through it, cut at the sill.
 */
export function PassWindow({ x, y, w, h, children }: { x: number; y: number; w: number; h: number; children: ReactNode }) {
  const id = useId().replace(/:/g, '')
  return (
    <div aria-hidden className="pointer-events-none absolute" style={{ left: x, top: y, width: w, height: h }}>
      <div className="absolute overflow-hidden" style={{ left: 6, top: 6, width: w - 12, height: h - 16, borderRadius: 6 }}>
        <svg width={w - 12} height={h - 16} viewBox={`0 0 ${w - 12} ${h - 16}`} className="absolute inset-0">
          <defs>
            <pattern id={`${id}-t`} width="22" height="16" patternUnits="userSpaceOnUse">
              <rect width="22" height="16" fill="#E9EFF9" />
              <path d="M 0 8 H 22 M 11 0 V 8 M 0 16 H 22" fill="none" stroke={LAB.lavender} strokeWidth={1} />
            </pattern>
          </defs>
          <rect width={w - 12} height={h - 16} fill={`url(#${id}-t)`} />
        </svg>
        {children}
      </div>
      <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} className="absolute inset-0" style={{ overflow: 'visible' }}>
        <rect x={2} y={2} width={w - 4} height={h - 10} rx={8} fill="none" stroke={STEEL_DK} strokeWidth={5} />
        <rect x={0} y={h - 12} width={w} height={8} rx={3} fill={STEEL_LT} stroke={STEEL_DK} strokeWidth={1.2} />
        {[w * 0.33, w * 0.67].map((cx) => (
          <g key={cx}>
            <rect x={cx - 1} y={2} width={2} height={10} fill={WIRE} />
            <path d={`M ${cx - 8} 18 L ${cx - 4} 11 H ${cx + 4} L ${cx + 8} 18 Z`} fill={LAB.red} />
            <ellipse cx={cx} cy={19} rx={5} ry={2} fill={LAB.yellow} opacity={0.9} />
          </g>
        ))}
      </svg>
    </div>
  )
}

/** A menu board on the wall: a dark board in a wood frame with chalk lines. */
export function MenuBoard({ w }: { w: number }) {
  const fx = useFx({ frame: LAB.wood })
  return (
    <ClaySvg w={w} vw={70} vh={54}>
      {fx.defs}
      <rect x={2} y={2} width={66} height={50} rx={4} fill={fx.g('frame')} />
      <rect x={7} y={7} width={56} height={40} rx={2} fill="#2F3A4A" />
      <rect x={14} y={14} width={26} height={3} rx={1.5} fill="#F7F2EA" opacity={0.9} />
      <rect x={14} y={22} width={40} height={2.2} rx={1.1} fill="#F7F2EA" opacity={0.6} />
      <rect x={14} y={29} width={34} height={2.2} rx={1.1} fill="#F7F2EA" opacity={0.6} />
      <rect x={14} y={36} width={38} height={2.2} rx={1.1} fill="#F7F2EA" opacity={0.6} />
      <rect x={50} y={14} width={8} height={3} rx={1.5} fill={LAB.yellow} opacity={0.9} />
    </ClaySvg>
  )
}

/** A menu card held open: two amber panels with their printed lines. */
export function MenuCard({ w }: { w: number }) {
  const fx = useFx({ page: '#FFF6E5' })
  return (
    <ClaySvg w={w} vw={48} vh={40}>
      {fx.defs}
      <path d="M 2 4 L 24 8 L 46 4 V 36 L 24 40 L 2 36 Z" fill={fx.g('page')} stroke={drop(AMBER, 0.05)} strokeWidth={1.4} />
      <path d="M 24 8 V 40" stroke={drop(AMBER, 0.05)} strokeWidth={1} />
      <rect x={6} y={12} width={12} height={2.4} rx={1.2} fill={AMBER} />
      {[18, 23, 28].map((y) => (
        <rect key={y} x={6} y={y} width={14} height={1.8} rx={0.9} fill="#C9B189" />
      ))}
      <rect x={29} y={12} width={12} height={2.4} rx={1.2} fill={AMBER} />
      {[18, 23, 28].map((y) => (
        <rect key={y} x={29} y={y} width={13} height={1.8} rx={0.9} fill="#C9B189" />
      ))}
    </ClaySvg>
  )
}

/** A recipe card: an amber-edged card with a title line and the steps. */
export function RecipeCard({ w }: { w: number }) {
  const fx = useFx({ page: '#FFF6E5' })
  return (
    <ClaySvg w={w} vw={40} vh={48}>
      {fx.defs}
      <rect x={2} y={2} width={36} height={44} rx={4} fill={fx.g('page')} stroke={AMBER} strokeWidth={2} />
      <rect x={8} y={9} width={18} height={3} rx={1.5} fill={AMBER} />
      {[17, 23, 29, 35].map((y) => (
        <rect key={y} x={8} y={y} width={24 - (y % 3) * 3} height={2} rx={1} fill="#C9B189" />
      ))}
    </ClaySvg>
  )
}

/* ------------------------------------------------------------------ the empty shell's services */

/**
 * The water supply: a pipe down the wall on two clamps, an elbow to a tap
 * with a blue handle and a curved spout, a drop under it while `drip`.
 */
export function WaterTap({ w, drip = false }: { w: number; drip?: boolean }) {
  const fx = useFx({ pipe: STEEL_DK, tap: STEEL_LT })
  return (
    <ClaySvg w={w} vw={60} vh={78}>
      {fx.defs}
      <path d="M 14 0 V 34 Q 14 40 20 40 H 38" fill="none" stroke={fx.g('pipe')} strokeWidth={6} strokeLinecap="round" />
      <rect x={9} y={10} width={10} height={4} rx={1} fill={drop(STEEL_DK, 0.3)} />
      <rect x={9} y={26} width={10} height={4} rx={1} fill={drop(STEEL_DK, 0.3)} />
      <rect x={40} y={27} width={4} height={9} rx={1.5} fill={STEEL_DK} />
      <rect x={34} y={24} width={16} height={4.5} rx={2} fill={LAB.cobalt} />
      <rect x={34} y={34} width={16} height={12} rx={4} fill={fx.g('tap')} stroke={drop(STEEL, 0.2)} strokeWidth={1} />
      <path d="M 46 40 q 10 0 10 10 v 6" fill="none" stroke={fx.g('tap')} strokeWidth={5} strokeLinecap="round" />
      <path d="M 56 60 q -4 6 0 9 q 4 -3 0 -9 Z" fill={LAB.sky} data-flat style={{ opacity: drip ? 1 : 0, transition: `opacity 300ms ${EASE}` }} />
    </ClaySvg>
  )
}

/** A wall socket: a pale plate with two holes and a switch. */
export function Socket({ w, on = false }: { w: number; on?: boolean }) {
  return (
    <ClaySvg w={w} vw={30} vh={22}>
      <rect x={1} y={1} width={28} height={20} rx={3} fill={STEEL_LT} stroke={drop(STEEL, 0.2)} strokeWidth={1} data-flat />
      <circle cx={10} cy={11} r={2} fill={CHARCOAL} data-flat />
      <circle cx={18} cy={11} r={2} fill={CHARCOAL} data-flat />
      <rect x={23} y={6} width={4} height={10} rx={1} fill={on ? LAB.red : STEEL_DK} data-flat style={{ transition: `fill 420ms ${EASE}` }} />
    </ClaySvg>
  )
}

/* ------------------------------------------------------------------ the PaaS flow's two ends */

/** A code file: a page with a folded amber corner, lines of code and a large `</>` mark. */
export function CodeFile({ w }: { w: number }) {
  const fx = useFx({ page: '#FFF8EC', fold: AMBER })
  return (
    <ClaySvg w={w} vw={90} vh={112}>
      {fx.defs}
      <Shadow id={fx.id} cx={45} cy={109} rx={36} ry={4} o={0.22} />
      <path d="M 12 4 H 58 L 80 26 V 100 a 6 6 0 0 1 -6 6 H 12 a 6 6 0 0 1 -6 -6 V 10 a 6 6 0 0 1 6 -6 Z" fill={fx.g('page')} stroke={drop(AMBER, 0.05)} strokeWidth={1.5} />
      <path d="M 58 4 V 20 a 6 6 0 0 0 6 6 H 80 Z" fill={fx.g('fold')} />
      {[[16, 30, 26], [16, 38, 40], [24, 46, 30]].map(([x, y, l], i) => (
        <rect key={i} x={x} y={y} width={l} height={4} rx={2} fill={i === 1 ? '#D9C3A0' : lift(AMBER, 0.2)} />
      ))}
      <path d="M 31 64 l -11 12 l 11 12 M 59 64 l 11 12 l -11 12 M 50 60 l -10 32" fill="none" stroke={AMBER} strokeWidth={5} strokeLinecap="round" strokeLinejoin="round" />
    </ClaySvg>
  )
}

/** A browser window: a title bar with the three dots and an address pill, and in its viewport an app (header, sidebar, cards) that lights while it runs. */
export function BrowserWindow({ w, lit }: { w: number; lit: boolean }) {
  const fx = useFx({ frame: STEEL_LT, bar: STEEL })
  return (
    <ClaySvg w={w} vw={150} vh={112}>
      {fx.defs}
      <Shadow id={fx.id} cx={75} cy={109} rx={62} ry={4} o={0.22} />
      <Slab x={4} y={4} w={142} h={100} rx={8} d={6} hue={STEEL_LT} fill={fx.g('frame')} />
      <path d="M 4 12 a 8 8 0 0 1 8 -8 H 138 a 8 8 0 0 1 8 8 V 22 H 4 Z" fill={fx.g('bar')} />
      <circle cx={14} cy={13} r={3} fill={LAB.red} />
      <circle cx={23} cy={13} r={3} fill={LAB.yellow} />
      <circle cx={32} cy={13} r={3} fill={LAB.green} />
      <rect x={42} y={9} width={96} height={8} rx={4} fill="#FFFFFF" opacity={0.85} />
      <rect x={48} y={12} width={36} height={2.4} rx={1.2} fill={STEEL_DK} />
      <rect x={10} y={28} width={130} height={70} rx={4} fill="#FFFFFF" />
      <g style={{ opacity: lit ? 1 : 0.18, transition: `opacity 420ms ${EASE}` }}>
        <path d="M 10 32 a 4 4 0 0 1 4 -4 H 136 a 4 4 0 0 1 4 4 V 41 H 10 Z" fill={colors.brand} />
        <rect x={16} y={31.5} width={28} height={6} rx={3} fill="#FFFFFF" opacity={0.9} />
        <rect x={16} y={47} width={34} height={45} rx={3} fill={LAB.lavender} />
        <rect x={56} y={47} width={38} height={20} rx={3} fill={lift(AMBER, 0.55)} />
        <rect x={100} y={47} width={34} height={20} rx={3} fill={lift(AMBER, 0.55)} />
        <rect x={56} y={72} width={78} height={20} rx={3} fill={LAB.lavender} />
        <rect x={62} y={78} width={50} height={3} rx={1.5} fill={STEEL_DK} />
        <rect x={62} y={84} width={30} height={3} rx={1.5} fill={STEEL_DK} />
      </g>
    </ClaySvg>
  )
}

/* ------------------------------------------------------------------ the people */

/** The chef (a Character Lab figure; `props` on `Posed` adds the baker's cap and apron). */
export const CHEF_CFG: CharacterConfig = {
  name: 'Chef',
  gender: 'male',
  art: 'soft',
  shading: 'clay',
  skinTone: '#E0A87E',
  hair: { style: 'short', color: '#1B1E2E' },
  face: { jaw: 'round', brows: 'medium', eyes: 'big', mouth: 'full' },
  outfit: { top: 'shirt', topColor: '#FFFFFF', bottom: 'trousers', bottomColor: '#3E3D45', shoeColor: '#2A2A30' },
  accessories: {},
  build: { height: 0.95, shoulders: 1 },
}

/** The restaurant owner: a blue shirt, a short beard, a watch; the one who manages everything. */
export const OWNER_CFG: CharacterConfig = {
  name: 'Owner',
  gender: 'male',
  art: 'soft',
  shading: 'clay',
  skinTone: '#D9A074',
  hair: { style: 'sidePart', color: '#2A1E16' },
  face: { jaw: 'square', brows: 'thick', eyes: 'big', mouth: 'full' },
  outfit: { top: 'shirt', topColor: '#2D63FB', bottom: 'trousers', bottomColor: '#1F2A4A', shoeColor: '#2A2A30' },
  accessories: { beard: 'short', watch: true },
  build: { height: 1, shoulders: 1.02 },
}

/** Two kitchen staff, hired: with `props` each wears the cap and apron. */
export const STAFF_A: CharacterConfig = {
  name: 'Staff A',
  gender: 'female',
  art: 'soft',
  shading: 'clay',
  skinTone: '#C98B60',
  hair: { style: 'bun', color: '#1B1E2E' },
  face: { jaw: 'oval', brows: 'thin', eyes: 'big', mouth: 'full' },
  outfit: { top: 'tshirt', topColor: '#FFFFFF', bottom: 'trousers', bottomColor: '#3E3D45', shoeColor: '#2A2A30' },
  accessories: {},
  build: { height: 0.92, shoulders: 0.9 },
}
export const STAFF_B: CharacterConfig = {
  name: 'Staff B',
  gender: 'male',
  art: 'soft',
  shading: 'clay',
  skinTone: '#F2C29B',
  hair: { style: 'curly', color: '#1B1E2E' },
  face: { jaw: 'round', brows: 'medium', eyes: 'big', mouth: 'full' },
  outfit: { top: 'tshirt', topColor: '#FFFFFF', bottom: 'trousers', bottomColor: '#3E3D45', shoeColor: '#2A2A30' },
  accessories: {},
  build: { height: 0.9, shoulders: 0.95 },
}

/** The waiter: a white shirt and tie, dark trousers, a side parting. */
export const WAITER_CFG: CharacterConfig = {
  name: 'Waiter',
  gender: 'male',
  art: 'soft',
  shading: 'clay',
  skinTone: '#E0A87E',
  hair: { style: 'sidePart', color: '#1B1E2E' },
  face: { jaw: 'oval', brows: 'medium', eyes: 'big', mouth: 'full' },
  outfit: { top: 'shirtTie', topColor: '#FFFFFF', bottom: 'trousers', bottomColor: '#1F2230', shoeColor: '#2A2A30', accentColor: '#1F2230' },
  accessories: {},
  build: { height: 0.96, shoulders: 0.98 },
}

/** The whole figure, with room on both sides for a reaching arm (service.tsx's chef crop). */
export const FULL_CROP = { x0: -30, y0: -40, x1: 400, y1: 595 }

/** A dining chair's back, seen behind a seated person: a wood backrest with its inner panel and top rail. */
export function ChairBack({ w }: { w: number }) {
  const fx = useFx({ wood: LAB.wood })
  return (
    <ClaySvg w={w} vw={70} vh={70}>
      {fx.defs}
      <rect x={8} y={4} width={54} height={66} rx={9} fill={fx.g('wood')} />
      <rect x={15} y={12} width={40} height={50} rx={6} fill={drop(LAB.wood, 0.12)} />
      <rect x={14} y={6} width={42} height={2.5} rx={1.2} fill="#FFFFFF" opacity={0.35} />
    </ClaySvg>
  )
}
