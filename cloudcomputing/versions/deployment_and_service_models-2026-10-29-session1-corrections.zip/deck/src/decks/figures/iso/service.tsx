import type { CSSProperties, ReactNode } from 'react'
import { colors } from '@/design/tokens'
import { Arrow, At, Label, Traveller, useLoop } from '../scene'
import { ClaySvg } from '../art'
import { useFx, Slab } from '../clay-a'
import { Shadow } from '../depth'
import { ClayBar, ClayClipboard, ClayFridge, ClayLaptop, ClayMonitor, ClayParcel, ClayPhone, ClayRack, ElectricMeter, GroundShadow, Icon3D, LAB, RichCloud } from '../d3/kit'
import { AN_W, Chips, FigureOnly, IsoAnalogy, PointsFigure } from './frames'
import { HALF, Posed } from '../Cast'
import { BrowserWindow, ChairBack, CodeFile, FULL_CROP, MenuBoard, MenuCard, OWNER_CFG, PassWindow, RealOven, RecipeCard, Room, RoundTable, Socket, STAFF_A, STAFF_B, Stand, SteelCounter, StoveStation, UtensilRail, WAITER_CFG, WaterTap } from './rooms'
import type { CharacterConfig } from '../cast/skins/config'
import vpcMark from '../d3/aws/virtual-private-cloud-vpc.svg'
import publicSubnetMark from '../d3/aws/public-subnet.svg'
import privateSubnetMark from '../d3/aws/private-subnet.svg'
import ec2Mark from '../d3/aws/ec2-instance.svg'

/**
 * SECTION 3 · SERVICE MODELS (reference frames 25 to 32), in session 1's 3D
 * look (2026-10-26): front-facing glossy slabs (`ClayBar`, slide 19 of
 * session 1's hypervisor stack), the rich cloud, library renders and session
 * 1's drawn devices, each on a soft ground shadow; labels are DOM chips.
 *
 * Every figure runs one loop whose motion is the claim: the ownership line
 * glides across the three stacks from IaaS to SaaS, the TR's two examples
 * light on the deployment x service grid, packets drip from the IaaS cloud
 * into raw compute, storage and network, the customer's application is
 * lowered onto the PaaS platform, the SaaS cloud lights three devices'
 * screens. The three pizza analogies share one four-layer stack
 * (Infrastructure, Operating system, Runtime, Application) and the everyday
 * scene and the stack run on one clock, so what the customer carries in
 * arrives on both sides at the same moment. Blue is the provider's, amber the
 * customer's.
 */

const EASE = 'cubic-bezier(0.22,1,0.36,1)'
const PROVIDER = colors.brand
const CUSTOMER = '#F5A623' // the iso engine's customer amber (ISO.customer)
const CUSTOMER_INK = '#5E3700'

type Owner = 'P' | 'C'
const ownerColor = (o: Owner) => (o === 'P' ? PROVIDER : CUSTOMER)

/** 0 before a, 1 after b, eased between. */
function within(t: number, a: number, b: number) {
  if (t <= a) return 0
  if (t >= b) return 1
  const x = (t - a) / (b - a)
  return x * x * (3 - 2 * x)
}

/** A labelled slab in an owner's colour: the session 1 hypervisor bar. */
function OwnerSlab({ w, h, owner, children, size = 15 }: { w: number; h: number; owner: Owner; children?: ReactNode; size?: number }) {
  return (
    <ClayBar w={w} h={h} fill={ownerColor(owner)}>
      {children !== undefined && (
        <span className="font-heading font-semibold" style={{ fontSize: size, color: owner === 'P' ? colors.white : CUSTOMER_INK }}>
          {children}
        </span>
      )}
    </ClayBar>
  )
}

/* ------------------------------------------------------------------ local drawings, session 1's finish */

/** An oven: a provider-blue body lit from the upper left, a dark window that glows warm while it bakes, two knobs. */
/* replaced on 2026-10-29 by the room scenes below; kept, unused */
export function ClayOven({ w, on = false }: { w: number; on?: boolean }) {
  const fx = useFx({ body: LAB.cobalt, glass: LAB.navy, knob: LAB.lavender, warm: LAB.orange })
  return (
    <ClaySvg w={w} vw={120} vh={124}>
      {fx.defs}
      <Shadow id={fx.id} cx={60} cy={119} rx={54} ry={4} o={0.24} />
      <g>
        <Slab x={4} y={8} w={108} h={106} rx={14} d={6} hue={LAB.cobalt} fill={fx.g('body')} />
      </g>
      <g>
        <rect x={16} y={20} width={84} height={14} rx={7} fill={LAB.navy} opacity={0.35} />
        <circle cx={30} cy={27} r={5} fill={fx.g('knob')} />
        <circle cx={48} cy={27} r={5} fill={fx.g('knob')} />
        <circle cx={28.5} cy={25.5} r={1.6} fill="#FFFFFF" opacity={0.8} />
        <circle cx={46.5} cy={25.5} r={1.6} fill="#FFFFFF" opacity={0.8} />
        <rect x={64} y={24} width={28} height={6} rx={3} fill={LAB.lavender} opacity={0.8} />
      </g>
      <g>
        <rect x={16} y={44} width={84} height={58} rx={10} fill={fx.g('glass')} />
        <rect x={16} y={44} width={84} height={58} rx={10} fill={fx.g('warm')} style={{ opacity: on ? 0.85 : 0, transition: `opacity 520ms ${EASE}` }} />
        <path d="M 22 48 L 58 48 L 22 84 Z" fill="#FFFFFF" opacity={0.16} />
        <rect x={30} y={40} width={56} height={5} rx={2.5} fill={LAB.lavender} />
      </g>
    </ClaySvg>
  )
}

const DOUGH = '#F3D29A'
const SAUCE = '#D8352F'
const CHEESE = '#FCC82B'
const BASIL = '#6E9A72'

/** A pizza on its tray, seen from the front and above: `stage` -1 none, 0 dough, 1 sauce, 2 cheese, 3 toppings. */
function ClayPizza({ w, stage, tray = LAB.lavDeep, opacity = 1 }: { w: number; stage: number; tray?: string; opacity?: number }) {
  const fx = useFx({ tray, dough: DOUGH, sauce: SAUCE, cheese: CHEESE })
  const show = (s: number): CSSProperties => ({ opacity: stage >= s ? opacity : 0, transition: `opacity 420ms ${EASE}` })
  return (
    <ClaySvg w={w} vw={110} vh={50}>
      {fx.defs}
      <Shadow id={fx.id} cx={55} cy={44} rx={50} ry={4} o={0.2} />
      <g>
        <ellipse cx={55} cy={30} rx={52} ry={15} fill={drop2(tray)} />
        <ellipse cx={55} cy={27} rx={52} ry={15} fill={fx.g('tray')} />
        <ellipse cx={42} cy={21} rx={20} ry={4} fill="#FFFFFF" opacity={0.25} />
      </g>
      <g style={show(0)}>
        <ellipse cx={55} cy={27} rx={42} ry={11} fill={fx.g('dough')} />
        <ellipse cx={46} cy={23} rx={16} ry={3} fill="#FFFFFF" opacity={0.35} />
      </g>
      <g style={show(1)}>
        <ellipse cx={55} cy={27} rx={35} ry={8.5} fill={fx.g('sauce')} />
      </g>
      <g style={show(2)}>
        {[[40, 25], [55, 23], [70, 26], [48, 30], [63, 31]].map(([x, y], i) => (
          <ellipse key={i} cx={x} cy={y} rx={8} ry={3.4} fill={fx.g('cheese')} />
        ))}
      </g>
      <g style={show(3)}>
        {[[36, 27, SAUCE], [52, 26, BASIL], [66, 23, SAUCE], [74, 29, BASIL], [58, 31, SAUCE], [45, 22, BASIL]].map(([x, y, c], i) => (
          <circle key={i} cx={x as number} cy={y as number} r={2.8} fill={c as string} />
        ))}
      </g>
    </ClaySvg>
  )
}
const drop2 = (c: string) => (c === LAB.lavDeep ? '#8EA3D6' : '#1C4FD6')

/** A kitchen counter: a wooden top with a lit edge over pale cupboard doors. */
/* replaced on 2026-10-29 by the room scenes below; kept, unused */
export function ClayCounter({ w }: { w: number }) {
  const fx = useFx({ wood: LAB.wood, door: LAB.paper })
  return (
    <ClaySvg w={w} vw={170} vh={78}>
      {fx.defs}
      <Shadow id={fx.id} cx={85} cy={74} rx={80} ry={4} o={0.22} />
      <g>
        <Slab x={10} y={20} w={150} h={52} rx={8} d={0} hue={LAB.lavDeep} fill={fx.g('door')} spec={false} />
        <rect x={20} y={28} width={62} height={36} rx={6} fill={LAB.lavender} />
        <rect x={88} y={28} width={62} height={36} rx={6} fill={LAB.lavender} />
        <rect x={70} y={40} width={4} height={12} rx={2} fill={LAB.navy} opacity={0.6} />
        <rect x={96} y={40} width={4} height={12} rx={2} fill={LAB.navy} opacity={0.6} />
      </g>
      <g>
        <Slab x={4} y={8} w={162} h={14} rx={6} d={4} hue={LAB.wood} fill={fx.g('wood')} />
      </g>
    </ClaySvg>
  )
}

/* ================================================================== 25 · three stacks */

const LAYERS = ['Virtualization, servers, storage, network', 'Operating system', 'Runtime & middleware', 'Data & access configuration', 'Application'] // bottom to top
const MODELS: { name: string; owners: Owner[]; split: number }[] = [
  { name: 'IaaS', owners: ['P', 'C', 'C', 'C', 'C'], split: 1 },
  { name: 'PaaS', owners: ['P', 'P', 'P', 'C', 'C'], split: 3 },
  { name: 'SaaS', owners: ['P', 'P', 'P', 'C', 'P'], split: 3 },
]

/**
 * Three stacks of five front-facing slabs, each in the TR table's owner
 * colour with the cell word on it, laid out as the TR's table: `Stack layer`
 * and the layer names in a left-aligned column, the three model heads centred
 * over their columns in the same style, even rows, the legend under the grid.
 * Each column's ownership line is drawn once, in the gap at its split (static:
 * 2026-10-27 the gliding line read as a glitch); the loop lights one column at
 * a time, IaaS, PaaS, SaaS.
 */
function TowersScene() {
  const t = useLoop(9000, { mode: 'sawtooth', still: 0.4 })
  const lit = Math.min(2, Math.floor(t * 3))
  const SW = 196
  const SH = 44
  const GAP = 10
  const LX = 52 // the layer column's left edge
  const LW = 330
  const C0 = 418 // the first model column's left edge
  const CG = 24
  const HEAD = 46
  const Y0 = 76
  const colX = (i: number) => C0 + i * (SW + CG)
  const rowTop = (k: number) => Y0 + (4 - k) * (SH + GAP) // k counts from the bottom
  const gridBottom = rowTop(0) + SH
  const head = 'font-heading text-[18px] font-semibold'
  return (
    <>
      <At x={LX} y={HEAD} cy w={LW}>
        <div className={head} style={{ color: colors.brandDark }}>
          Stack layer
        </div>
      </At>
      {LAYERS.map((name, k) => (
        <At key={name} x={LX} y={rowTop(k) + SH / 2} cy w={LW}>
          <div className="font-heading text-[17px] font-medium leading-tight" style={{ color: colors.ink }}>
            {name}
          </div>
        </At>
      ))}
      {MODELS.map((m, i) => (
        <div key={`g-${m.name}`} aria-hidden className="pointer-events-none absolute rounded-2xl" style={{ left: colX(i) - 10, top: HEAD - 22, width: SW + 20, height: gridBottom - HEAD + 34, background: colors.brand, opacity: lit === i ? 0.08 : 0, transition: `opacity 420ms ${EASE}` }} />
      ))}
      {MODELS.map((m, i) => (
        <At key={m.name} x={colX(i) + SW / 2} y={HEAD} cx cy>
          <div className={head} style={{ color: lit === i ? colors.brand : colors.brandDark, transition: `color 420ms ${EASE}` }}>
            {m.name}
          </div>
        </At>
      ))}
      {MODELS.map((m, i) => (
        <At key={`s-${m.name}`} x={colX(i)} y={Y0}>
          <div className="flex flex-col" style={{ gap: GAP }}>
            {[...m.owners].reverse().map((o, j) => (
              <OwnerSlab key={j} w={SW} h={SH} owner={o} size={16}>
                {o === 'P' ? 'Provider' : 'Customer'}
              </OwnerSlab>
            ))}
          </div>
        </At>
      ))}
      {MODELS.map((m, i) => (
        <div key={`l-${m.name}`} aria-hidden className="pointer-events-none absolute rounded-full" style={{ left: colX(i) - 6, top: rowTop(m.split - 1) - GAP / 2 - 1.5, width: SW + 12, height: 3, background: colors.brandDark, opacity: lit === i ? 1 : 0.35, transition: `opacity 420ms ${EASE}` }} />
      ))}
      <At x={555} y={gridBottom + 42} cx cy>
        <Chips
          items={[
            { text: 'Provider manages', color: PROVIDER },
            { text: 'Customer manages', color: CUSTOMER },
          ]}
        />
      </At>
    </>
  )
}

export function StackMap({ lesson }: { lesson: string }) {
  return <FigureOnly id="stack" kicker="Service Model Spectrum" title="Stack Ownership Map" lead="The three service models share one technology stack; each shifts the line dividing provider-managed layers from customer-managed layers" lesson={lesson} figure={<TowersScene />} h={410} />
}

/* ================================================================== 26 · any service model on any deployment model */

const DEPLOY = ['Public', 'Private', 'Hybrid', 'Community']
const SERVICE = ['IaaS', 'PaaS', 'SaaS']

/**
 * 2026-10-27 (the user: replace the grid with an illustration): the service
 * models as one layer stack (the library's layers render, IaaS PaaS SaaS under
 * it) fanning out to the four deployment clouds; the TR's two examples light in
 * turn, a packet riding out to Private with IaaS lit, then to Public with SaaS.
 */
function GridScene() {
  const t = useLoop(9000, { mode: 'sawtooth', still: 0.25 })
  const examples = [
    { name: 'Private-cloud IaaS', d: 1, sv: 0 },
    { name: 'Public-cloud SaaS', d: 0, sv: 2 },
  ]
  const which = t < 0.5 ? 0 : 1
  const ex = examples[which]
  const u = (t % 0.5) / 0.5
  const going = u > 0.04 && u < 0.36
  const on = u >= 0.36 && u < 0.96
  const LCX = 250
  const HUB: [number, number] = [372, 150]
  const CLX = 668 // the clouds' centre
  const ROWS = [62, 136, 210, 284]
  const CW = 78
  return (
    <>
      <At x={LCX} y={34} cx>
        <Icon3D name="layers" w={176} />
      </At>
      <At x={LCX} y={262} cx>
        <div className="flex items-center gap-2.5">
          {SERVICE.map((name, j) => (
            <Label key={name} size={16} strong tone={on && ex.sv === j ? 'solid' : 'brand'}>
              {name}
            </Label>
          ))}
        </div>
      </At>
      {DEPLOY.map((name, i) => (
        <Arrow key={`a-${name}`} x1={HUB[0]} y1={HUB[1]} x2={CLX - CW / 2 - 10} y2={ROWS[i]} dashed tone={ex.d === i && (going || on) ? colors.brand : colors.line} />
      ))}
      <Traveller path={[HUB, [CLX - CW / 2 - 14, ROWS[ex.d]]]} run={going} k={`g-${which}`} size={12} tone={colors.brand} dur={2.2} />
      {DEPLOY.map((name, i) => {
        const lit = on && ex.d === i
        return (
          <At key={name} x={CLX - CW / 2} y={ROWS[i]} cy>
            <div className="flex items-center gap-4">
              <div className="relative" style={{ width: CW }}>
                <Glow on={lit} w={CW + 50} h={CW + 20} />
                <div className="relative">
                  <RichCloud w={CW} />
                </div>
              </div>
              <span className="font-heading text-[18px] font-semibold" style={{ color: lit ? colors.brand : colors.ink, width: 112, transition: `color 420ms ${EASE}` }}>
                {name}
              </span>
              {examples.map((e) =>
                e.d === i ? (
                  <Label key={e.name} size={16} strong tone={lit ? 'solid' : 'plain'}>
                    {e.name}
                  </Label>
                ) : null,
              )}
            </div>
          </At>
        )
      })}
    </>
  )
}

export function StackGrid({ lesson }: { lesson: string }) {
  return (
    <FigureOnly
      id="stack-grid"
      kicker="Service Model Spectrum"
      title="Stack Ownership Map"
      lead={['Deployment models say where the infrastructure sits and who owns it; service models say what is abstracted', 'Any service model can run on any deployment model (for example, private-cloud IaaS, public-cloud SaaS)']}
      lesson={lesson}
      figure={<GridScene />}
      h={340}
    />
  )
}

/* ================================================================== 27 · IaaS */

/** A soft glow behind an object that lights while `on`. */
function Glow({ on, w, h, tone = colors.brand }: { on: boolean; w: number; h: number; tone?: string }) {
  return <div aria-hidden className="pointer-events-none absolute left-1/2 top-1/2 rounded-full" style={{ width: w, height: h, transform: 'translate(-50%,-50%)', background: `radial-gradient(closest-side, ${tone}55, ${tone}00)`, opacity: on ? 1 : 0, transition: `opacity 420ms ${EASE}` }} />
}

/**
 * 2026-10-27 (the user: the router icon becomes a virtual network diagram): a
 * VPC drawn the AWS way (the official marks, slide-kit/assets/aws: VPC purple,
 * solid; a public subnet green and a private subnet teal), an instance in each,
 * linked.
 */
function VirtualNetwork({ on }: { on: boolean }) {
  const sub = (mark: string, tone: string) => (
    <div className="relative grid place-items-center rounded-[5px] bg-white" style={{ width: 52, height: 56, boxShadow: `inset 0 0 0 2px ${tone}` }}>
      <img src={mark} alt="" draggable={false} className="absolute left-0 top-0" style={{ width: 15, height: 15 }} />
      <img src={ec2Mark} alt="" draggable={false} style={{ width: 28, height: 28, marginTop: 8 }} />
    </div>
  )
  return (
    <div className="flex flex-col items-center">
      <div className="relative flex items-center rounded-[8px] bg-white" style={{ width: 138, height: 92, padding: '22px 8px 8px', gap: 18, boxShadow: `inset 0 0 0 2px #8C4FFF, 0 12px 22px -14px rgba(16,32,58,0.5)` }}>
        <img src={vpcMark} alt="" draggable={false} className="absolute left-0 top-0" style={{ width: 20, height: 20 }} />
        {sub(publicSubnetMark, '#7AA116')}
        {sub(privateSubnetMark, '#00A4A6')}
        <div aria-hidden className="pointer-events-none absolute" style={{ left: 54, right: 54, top: 63, height: 2.5, background: on ? colors.brand : '#8C4FFF', transition: `background 420ms ${EASE}` }} />
      </div>
      <GroundShadow w={138} />
    </div>
  )
}

/** The TR's diagram: a cloud labelled IaaS over a rack, a database and a virtual network; packets drip down three arrows in turn and each block lights as one lands. */
function IaasScene() {
  const t = useLoop(7200, { mode: 'sawtooth', still: 0.3 })
  const start = (i: number) => i * 0.22 + 0.04
  const dripping = (i: number) => t >= start(i) && t < start(i) + 0.26
  const landed = (i: number) => (t - (start(i) + 0.26) + 1) % 1 < 0.3
  const items: { name: string; x: number; top: number; art: (on: boolean) => ReactNode }[] = [
    { name: 'Compute', x: 147, top: 204, art: (on) => <ClayRack w={86} units={on ? ['run', 'run', 'run'] : ['run', 'idle', 'idle']} /> },
    { name: 'Storage', x: 317, top: 204, art: () => <Icon3D name="database" w={80} /> },
    { name: 'Network', x: 487, top: 196, art: (on) => <VirtualNetwork on={on} /> },
  ]
  /* review 2026-10-26 (connections): out of the cloud's underside, onto each object's top */
  const SRC: [number, number][] = [[278, 158], [317, 162], [356, 158]]
  return (
    <>
      <At x={317} y={24} cx>
        <Label size={18} strong tone="solid">
          IaaS
        </Label>
      </At>
      <At x={317} y={62} cx>
        <RichCloud w={160} />
      </At>
      {items.map((it, i) => (
        <Arrow key={`a-${i}`} x1={SRC[i][0]} y1={SRC[i][1]} x2={it.x} y2={it.top - 2} tone={landed(i) || dripping(i) ? colors.brand : colors.line} />
      ))}
      {items.map((it, i) => (
        <Traveller key={`t-${i}`} path={[SRC[i], [it.x, it.top - 8]]} run={dripping(i)} k={i} size={12} tone={colors.brand} dur={1.8} />
      ))}
      {items.map((it, i) => (
        <At key={it.name} x={it.x} y={300} cx>
          <div className="flex flex-col items-center gap-2" style={{ transform: 'translateY(-100%)' }}>
            <div className="relative flex items-end">
              <Glow on={landed(i)} w={150} h={120} />
              <div className="relative">{it.art(landed(i))}</div>
            </div>
          </div>
        </At>
      ))}
      {items.map((it, i) => (
        <At key={`l-${it.name}`} x={it.x} y={312} cx>
          <Label size={15} strong tone={landed(i) ? 'brand' : 'plain'}>
            {it.name}
          </Label>
        </At>
      ))}
    </>
  )
}

export function Iaas({ lesson }: { lesson: string }) {
  return (
    <PointsFigure
      id="iaas"
      kicker="IaaS Explained"
      title="Raw Infrastructure Rental"
      lead="Infrastructure as a Service rents compute, storage and network as raw building blocks, leaving the operating system and everything above it to the customer"
      lesson={lesson}
      points={['Abstracts physical hardware, racking and data-centre wiring', 'Customer installs OS, runtime, middleware and application', 'Representative services: AWS (Amazon Web Services) EC2, EBS, VPC', 'Azure Virtual Machines, GCP Compute Engine offer same layer']}
      figure={<IaasScene />}
    />
  )
}

/* ================================================================== the shared four-layer stack (28, 30, 32) */

const STACK4 = ['Infrastructure', 'Operating system', 'Runtime', 'Application'] // bottom to top
const AN_LAP = 9000
const fadeOut = (t: number) => 1 - within(t, 0.9, 0.98)

/**
 * The analogy's cloud side: four front-facing slabs, bottom to top, in their
 * owners' colours. `arrive[k]` is the phase at which slab k drops in (null:
 * there from the start); arrived slabs fade out at the end of the lap so it
 * loops. `data` adds the customer's one amber parcel under the stack.
 */
function Stack4({ owners, arrive, data = false, dataArrive = null }: { owners: Owner[]; arrive: (number | null)[]; data?: boolean; dataArrive?: number | null }) {
  const t = useLoop(AN_LAP, { mode: 'sawtooth', still: 0.75 })
  const SW = 180
  const SH = 42
  const GAP = 8
  const X = 64
  const Y0 = data ? 30 : 50
  const inK = (a: number | null) => (a === null ? 1 : within(t, a, a + 0.14) * fadeOut(t))
  const rowTop = (k: number) => Y0 + (3 - k) * (SH + GAP)
  const dataK = data ? inK(dataArrive) : 0
  return (
    <>
      {STACK4.map((_, k) => {
        const a = inK(arrive[k])
        return (
          <At key={`s-${k}`} x={X} y={rowTop(k)}>
            <div style={{ opacity: a, transform: `translateY(${-(1 - a) * 28}px)` }}>
              <OwnerSlab w={SW} h={SH} owner={owners[k]} />
            </div>
          </At>
        )
      })}
      <At x={X} y={rowTop(0) + SH + 2}>
        <GroundShadow w={SW} style={{ marginTop: 0 }} />
      </At>
      {STACK4.map((name, k) => (
        <At key={name} x={X + SW + 16} y={rowTop(k) + SH / 2} cy style={{ opacity: Math.max(0.35, inK(arrive[k])), transition: `opacity 420ms ${EASE}` }}>
          <Label size={14} strong tone={owners[k] === 'P' ? 'lift' : 'warn'}>
            {name}
          </Label>
        </At>
      ))}
      {data && (
        <At x={X + SW / 2} y={rowTop(0) + SH + 20} cx style={{ opacity: Math.max(0.35, dataK) }}>
          <div className="flex items-center gap-3">
            <div style={{ transform: `translateY(${-(1 - dataK) * 20}px)` }}>
              <ClayParcel w={40} tone={CUSTOMER} />
            </div>
            <Label size={14} strong tone="warn">
              Your data
            </Label>
          </div>
        </At>
      )}
    </>
  )
}

/** The chef who brings the customer's part (a Character Lab figure with the baker's cap and apron). */
const CHEF: CharacterConfig = {
  name: 'Chef',
  gender: 'male',
  art: 'soft',
  shading: 'clay',
  skinTone: '#E0A87E',
  hair: { style: 'short', color: '#1B1E2E' },
  face: { jaw: 'round', brows: 'medium', eyes: 'big', mouth: 'full' },
  outfit: { top: 'shirt', topColor: '#FFFFFF', bottom: 'trousers', bottomColor: '#3E3D45', shoeColor: '#2A2A30' },
  accessories: {},
  build: { height: 0.95, shoulders: 1 },
}
/* x1 widened (2026-10-28, the user: the hand clipped at the crop's right edge) */
const CHEF_CROP = { x0: -30, y0: -40, x1: 400, y1: 595 }
const CHEF_S = 0.29

/**
 * The everyday kitchen, to the TR's guidance (2026-10-27): the provider's
 * equipment (counter, oven and its gas line) under one `Infrastructure` or
 * `Platform` label; the chef on the left brings the customer's part as amber
 * recipe cards (`cards`, each flying from his hand at its phase to a row above
 * the counter), and the pizza advances as each lands, then bakes.
 */
/* replaced on 2026-10-29 by the room scenes below; kept, unused */
export function Kitchen({ cards, stageAt, doughReady, equipment }: { cards: { text: string; at: number }[]; stageAt: [number, 0 | 1 | 2 | 3][]; doughReady: boolean; equipment: string }) {
  const t = useLoop(AN_LAP, { mode: 'sawtooth', still: 0.75 })
  let stage: number = doughReady ? 0 : -1
  for (const [a, st] of stageAt) if (t >= a) stage = st
  const fo = fadeOut(t)
  const baked = t > 0.66 && t < 0.92
  const FLOOR = 222
  void cards
  const COUNTER_X = 236
  const OVEN_X = 368
  return (
    <>
      <At x={18} y={FLOOR}>
        <div style={{ transform: 'translateY(-100%)' }}>
          {/* a subtle reach (2026-10-28, the user: the hand moved too much): a third of the gesture's amplitude */}
          <Posed cfg={CHEF} props scale={CHEF_S} crop={CHEF_CROP} gesture="presentRight" amplitude={0.3} at={0.9} expression="happy" />
        </div>
      </At>
      {/* the recipe-card chips above the counter were removed (2026-10-28, the user); `cards` still times the pizza */}
      {/* the gas line: out of the oven's back, down to the floor and away */}
      <div aria-hidden className="absolute rounded-full" style={{ left: OVEN_X + 50, top: FLOOR - 40, width: 6, height: 40, background: 'linear-gradient(90deg, #8A94A8, #5A6378)' }} />
      <div aria-hidden className="absolute rounded-full" style={{ left: OVEN_X + 50, top: FLOOR - 6, width: 446 - OVEN_X - 50, height: 6, background: 'linear-gradient(180deg, #8A94A8, #5A6378)' }} />
      <div aria-hidden className="absolute rounded-[3px]" style={{ left: 428, top: FLOOR - 14, width: 14, height: 14, background: LAB.yellow, boxShadow: 'inset 0 -2px 0 rgba(0,0,0,0.18)' }} />
      <At x={COUNTER_X} y={FLOOR} cx>
        <div className="flex flex-col items-center" style={{ transform: 'translateY(-100%)' }}>
          <div style={{ marginBottom: -16 }}>
            {/* the dough is the provider's when it comes ready; the rest arrives with the customer */}
            <ClayPizza w={112} stage={stage} tray={doughReady ? colors.brand : LAB.lavDeep} opacity={doughReady ? 1 : fo} />
          </div>
          <ClayCounter w={140} />
        </div>
      </At>
      <At x={OVEN_X} y={FLOOR} cx>
        <div style={{ transform: 'translateY(-100%)' }}>
          <ClayOven w={108} on={baked} />
        </div>
      </At>
      <div aria-hidden className="absolute" style={{ left: COUNTER_X - 70, top: FLOOR + 10, width: 446 - COUNTER_X + 70, height: 2, background: colors.brand, opacity: 0.4 }} />
      <At x={(COUNTER_X - 70 + 446) / 2} y={FLOOR + 30} cx cy>
        <Label size={15} strong tone="lift">
          {equipment}
        </Label>
      </At>
    </>
  )
}

/* ================================================================== 28 · an empty restaurant space */

const IAAS_IN = [0.1, 0.28, 0.46]
/** the room every restaurant scene stands in (`rooms.tsx`), and the line things stand on */
const SR = { x: 24, y: 40, w: 422, h: 182 }
const S_FLOOR = SR.y + SR.h - 10
const lerp = (a: [number, number], b: [number, number], k: number): [number, number] => [a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k]

/**
 * Review 2026-10-29, the TR's sentence drawn clause by clause: an empty
 * restaurant shell (bare walls, a bare floor) that comes with electricity
 * (the meter and its wiring to a socket) and water (a pipe down the wall to
 * a tap). The owner stands in it, clipboard under his arm, and does the rest
 * on the cloud side's clock: at `IAAS_IN[0]` the kitchen equipment is placed
 * (a counter and an oven drop in), at `IAAS_IN[1]` two staff walk in and are
 * hired, at `IAAS_IN[2]` the food is prepared on the counter and baked, the
 * meter turning and the tap running while the kitchen works. One person,
 * reaching across all of it, managing the whole operation.
 */
function ShellScene() {
  const t = useLoop(AN_LAP, { mode: 'sawtooth', still: 0.75 })
  const fo = fadeOut(t)
  const gear = within(t, IAAS_IN[0], IAAS_IN[0] + 0.14) * fo
  const staff = within(t, IAAS_IN[1], IAAS_IN[1] + 0.14) * fo
  let stage = -1
  for (const [a, st] of [[IAAS_IN[2], 0], [IAAS_IN[2] + 0.05, 1], [IAAS_IN[2] + 0.1, 2], [IAAS_IN[2] + 0.14, 3]] as [number, number][]) if (t >= a) stage = st
  const cooking = t >= IAAS_IN[2] && t < 0.92
  const baked = t > 0.66 && t < 0.92
  const dropIn = (k: number): CSSProperties => ({ opacity: k, transform: `translateY(${(1 - k) * -26}px)` })
  return (
    <>
      <Room {...SR} kind="shell" />
      {/* the services that come with the shell: the meter and its wiring to a socket, the pipe and the tap */}
      <At x={SR.x + 164} y={SR.y + 16}>
        <ElectricMeter w={36} value={0.2 + gear * 0.3 + (cooking ? 0.35 : 0)} spin={cooking} />
      </At>
      <svg aria-hidden className="pointer-events-none absolute inset-0" width={AN_W} height={300} style={{ overflow: 'visible' }}>
        <path d={`M ${SR.x + 182} ${SR.y + 58} V ${SR.y + 66} H ${SR.x + 252} V ${SR.y + 104}`} fill="none" stroke="#5A6378" strokeWidth={3} strokeLinejoin="round" />
      </svg>
      <At x={SR.x + 240} y={SR.y + 104}>
        <Socket w={24} on={cooking} />
      </At>
      <At x={SR.x + 108} y={SR.y}>
        <WaterTap w={48} drip={cooking} />
      </At>
      {/* the equipment, placed: a counter, then an oven */}
      <Stand x={SR.x + 205} b={S_FLOOR - 2} style={dropIn(gear)}>
        <div className="flex flex-col items-center">
          <div style={{ marginBottom: -14, opacity: stage >= 0 ? 1 : 0, transition: `opacity 420ms ${EASE}` }}>
            <ClayPizza w={96} stage={stage} tray={LAB.lavDeep} opacity={fo} />
          </div>
          <SteelCounter w={96} />
        </div>
      </Stand>
      <Stand x={SR.x + 292} b={S_FLOOR} style={dropIn(within(t, IAAS_IN[0] + 0.05, IAAS_IN[0] + 0.19) * fo)}>
        <RealOven w={58} on={baked} />
      </Stand>
      {/* the staff, hired: two cooks walk in from the right */}
      {[
        [SR.x + 352, STAFF_A],
        [SR.x + 402, STAFF_B],
      ].map(([x, cfg], i) => (
        <Stand key={i} x={x as number} b={S_FLOOR + 6} style={{ opacity: Math.min(1, staff * 2), transform: `translateX(${(1 - staff) * 60}px)` }}>
          <Posed cfg={cfg as CharacterConfig} props scale={0.17} crop={FULL_CROP} expression="happy" />
        </Stand>
      ))}
      <At x={SR.x + 378} y={SR.y + 48} cx style={{ opacity: staff > 0.9 ? 1 : 0, transition: `opacity 420ms ${EASE}` }}>
        <Label size={14} tone="brand" strong>
          Hired
        </Label>
      </At>
      {/* the owner, managing it all: the clipboard under one arm, the other reaching across the room */}
      <Stand x={SR.x + 56} b={S_FLOOR + 8}>
        <Posed cfg={OWNER_CFG} scale={0.22} crop={FULL_CROP} gesture="presentRight" amplitude={0.9} at={0.9} expression="happy" />
      </Stand>
      <At x={SR.x + 24} y={S_FLOOR - 64}>
        <ClayClipboard w={22} />
      </At>
      <At x={AN_W / 2} y={244} cx cy>
        <Label size={15} strong tone="lift">
          Infrastructure
        </Label>
      </At>
    </>
  )
}

export function IaasAnalogy({ lesson }: { lesson: string }) {
  return (
    <IsoAnalogy
      id="iaas-analogy"
      kicker="IaaS Explained"
      lesson={lesson}
      text="You use Domino’s kitchen space and oven, but you are responsible for choosing and preparing the ingredients and making the pizza. Similarly, with IaaS, the provider manages the physical infrastructure, while the customer manages the operating system, runtime, applications, and data."
      everyday={{ label: 'Rent the empty space, run everything yourself', scene: <ShellScene /> }}
      cloud={{ label: 'IaaS', scene: <Stack4 owners={['P', 'C', 'C', 'C']} arrive={[null, ...IAAS_IN]} /> }}
    />
  )
}

/* ================================================================== 29 · PaaS */

/**
 * Review 2026-10-29 (the user): the flow drawn as three things in a row.
 * Left, the customer's code file (amber); middle, the PaaS cloud over the
 * box of what the provider manages for it (OS, Runtime, Scaling, Patching);
 * right, the app running in a browser window. The code travels into the
 * platform, the platform holds it and lights, and the running app comes out
 * the other side and its screen lights. Code, then PaaS, then the running app.
 */
function PaasScene() {
  const t = useLoop(8000, { mode: 'sawtooth', still: 0.7 })
  const up = t > 0.06 && t < 0.3
  const held = t > 0.3 && t < 0.94
  const out = t > 0.4 && t < 0.62
  const running = t > 0.62 && t < 0.94
  const CODE: [number, number] = [112, 164]
  const APP: [number, number] = [524, 164]
  const IN: [number, number][] = [[162, 150], [240, 126]]
  const OUT: [number, number][] = [[394, 126], [450, 150]]
  return (
    <>
      <At x={317} y={24} cx>
        <Label size={18} strong tone="solid">
          PaaS
        </Label>
      </At>
      <At x={317} y={58} cx>
        <div className="relative">
          <Glow on={held} w={230} h={150} />
          <div className="relative">
            <RichCloud w={140} />
          </div>
        </div>
      </At>
      {/* what the provider manages, in a box under the cloud */}
      <At x={317} y={176} cx>
        <div className="flex flex-col items-center" style={{ gap: 10 }}>
          <div className="grid grid-cols-2 gap-2 rounded-[14px] p-3" style={{ background: 'rgba(45,99,251,0.08)', boxShadow: `inset 0 0 0 1.5px ${colors.brand}4D` }}>
            {['OS', 'Runtime', 'Scaling', 'Patching'].map((s) => (
              <div key={s} className="flex justify-center">
                <Label size={14} strong tone="lift">
                  {s}
                </Label>
              </div>
            ))}
          </div>
          <Label size={15} strong tone="brand">
            Managed by provider
          </Label>
        </div>
      </At>
      <Arrow x1={IN[0][0]} y1={IN[0][1]} x2={IN[1][0]} y2={IN[1][1]} tone={up || held ? colors.brand : colors.line} />
      <Arrow x1={OUT[0][0]} y1={OUT[0][1]} x2={OUT[1][0]} y2={OUT[1][1]} tone={out || running ? colors.brand : colors.line} />
      <Traveller path={IN} run={up} k="in" size={12} tone={CUSTOMER} dur={1.6} />
      <Traveller path={OUT} run={out} k="out" size={12} tone={colors.brand} dur={1.6} />
      {/* the customer's code file */}
      <At x={CODE[0]} y={CODE[1]} cx cy>
        <div className="flex flex-col items-center" style={{ gap: 10 }}>
          <CodeFile w={82} />
          <Label size={15} strong tone="warn">
            Your code (customer)
          </Label>
        </div>
      </At>
      {/* the app, running in a browser window */}
      <At x={APP[0]} y={APP[1]} cx cy>
        <div className="flex flex-col items-center" style={{ gap: 10 }}>
          <BrowserWindow w={150} lit={running} />
          <Label size={15} strong tone="brand">
            Running app
          </Label>
        </div>
      </At>
    </>
  )
}

export function Paas({ lesson }: { lesson: string }) {
  return (
    <PointsFigure
      id="paas"
      kicker="PaaS Explained"
      title="Ready-Made Platform"
      lead="Platform as a Service adds a managed operating system and runtime atop infrastructure, so the customer only builds, deploys and runs application code"
      lesson={lesson}
      points={['Abstracts OS patching, runtime setup and server scaling', 'Less control over OS-level tuning than IaaS allows', 'Representative services: AWS Elastic Beanstalk, AWS App Runner', 'Azure App Service, GCP App Engine offer same layer']}
      figure={<PaasScene />}
    />
  )
}

/* ================================================================== 30 · a fully equipped kitchen */

const PAAS_IN = 0.3
const PAAS_STAGES: [number, number][] = [[PAAS_IN + 0.14, 1], [PAAS_IN + 0.18, 2], [PAAS_IN + 0.22, 3]]

/**
 * Review 2026-10-29, the TR's sentence: a complete commercial kitchen, every
 * piece installed and ready before the loop starts: a fridge, a cooking
 * station with its pot, a steel counter, a double oven, the utensil rail on
 * the tiled wall. The chef brings only the recipe card (amber, in hand); at
 * `PAAS_IN` the food is prepared on the counter, the pot steams and the
 * oven bakes it. Nothing is carried in and nothing is maintained.
 */
function EquippedKitchenScene() {
  const t = useLoop(AN_LAP, { mode: 'sawtooth', still: 0.75 })
  let stage = 0
  for (const [a, st] of PAAS_STAGES) if (t >= a) stage = st
  const cooking = t > PAAS_IN && t < 0.92
  const baked = t > 0.66 && t < 0.92
  return (
    <>
      <Room {...SR} kind="kitchen" />
      <At x={SR.x + 236} y={SR.y + 12}>
        <UtensilRail w={100} />
      </At>
      <Stand x={SR.x + 150} b={S_FLOOR}>
        <ClayFridge w={44} />
      </Stand>
      <Stand x={SR.x + 215} b={S_FLOOR}>
        <StoveStation w={84} on={cooking} />
      </Stand>
      <Stand x={SR.x + 302} b={S_FLOOR - 2}>
        <div className="flex flex-col items-center">
          <div style={{ marginBottom: -14 }}>
            <ClayPizza w={96} stage={stage} tray={colors.brand} />
          </div>
          <SteelCounter w={96} />
        </div>
      </Stand>
      <Stand x={SR.x + 388} b={S_FLOOR}>
        <RealOven w={54} on={baked} double />
      </Stand>
      {/* the chef, the recipe card in the hand he lifts */}
      <Stand x={SR.x + 62} b={S_FLOOR + 8}>
        <Posed cfg={CHEF} props scale={0.23} crop={CHEF_CROP} gesture="presentRight" amplitude={0.3} at={0.9} expression="happy">
          <div className="absolute" style={{ left: 66, top: 78 }}>
            <RecipeCard w={26} />
          </div>
        </Posed>
      </Stand>
      <At x={AN_W / 2} y={244} cx cy>
        <Label size={15} strong tone="lift">
          Platform
        </Label>
      </At>
    </>
  )
}

export function PaasAnalogy({ lesson }: { lesson: string }) {
  return (
    <IsoAnalogy
      id="paas-analogy"
      kicker="PaaS Explained"
      lesson={lesson}
      text="Domino's kitchen, oven and ready dough are already set up, so only assembling and baking the pizza on that setup remains, just as the PaaS provider manages infrastructure, operating system and runtime while the customer manages only the application & data."
      everyday={{ label: 'Rent the equipped kitchen, bring your recipes', scene: <EquippedKitchenScene /> }}
      cloud={{ label: 'PaaS', scene: <Stack4 owners={['P', 'P', 'P', 'C']} arrive={[null, null, null, PAAS_IN]} /> }}
    />
  )
}

/* ================================================================== 31 · SaaS */

/**
 * The TR's own diagram (2026-10-27, redrawn to it): a cloud labelled SaaS at
 * the top, three dashed connectors dropping onto one soft panel of devices, a
 * desktop showing a folder, a phone with a check badge, a laptop showing
 * connected users with a download beside it. The application rides down each
 * connector in turn and the device's screen fills as it lands.
 */
function SaasScene() {
  const t = useLoop(8000, { mode: 'sawtooth', still: 0.62 })
  const start = (i: number) => 0.06 + i * 0.13
  const going = (i: number) => t >= start(i) && t < start(i) + 0.26
  const lit = (i: number) => t > start(i) + 0.26 && t < 0.94
  const pop = (i: number) => within(t, start(i) + 0.26, start(i) + 0.34) * (1 - within(t, 0.92, 0.98))
  const BASE = 344
  const MON = { x: 150, w: 170 }
  const PH = { x: 326, w: 56 }
  const LAP = { x: 482, w: 176 }
  const monH = (MON.w * 124) / 150
  const phH = (PH.w * 114) / 56
  const lapH = (LAP.w * 110) / 160
  const tops = [BASE - monH, BASE - phH, BASE - lapH]
  const xs = [MON.x, PH.x, LAP.x]
  const SRC: [number, number][] = [[282, 160], [PH.x, 166], [352, 160]] /* the phone's connector drops straight: it starts at the phone's own x (2026-10-30) */
  const ms = MON.w / 150
  const ls = LAP.w / 160
  const fill = (i: number): CSSProperties => ({ opacity: pop(i), transform: `scale(${0.85 + 0.15 * pop(i)})`, transition: `opacity 300ms ${EASE}` })
  return (
    <>
      <div aria-hidden className="absolute rounded-[22px]" style={{ left: 34, top: 226, width: 566, height: 130, background: `linear-gradient(180deg, ${LAB.lavender}, rgba(45,99,251,0.10))`, boxShadow: 'inset 0 0 0 1px rgba(45,99,251,0.12)' }} />
      <At x={317} y={24} cx>
        <Label size={18} strong tone="solid">
          SaaS
        </Label>
      </At>
      <At x={317} y={58} cx>
        <RichCloud w={156} />
      </At>
      {xs.map((x, i) => (
        <Arrow key={`a-${i}`} x1={SRC[i][0]} y1={SRC[i][1]} x2={x} y2={tops[i] - 4} dashed tone={going(i) || lit(i) ? colors.brand : colors.line} />
      ))}
      {xs.map((x, i) => (
        <Traveller key={`t-${i}`} path={[SRC[i], [x, tops[i] - 10]]} run={going(i)} k={i} size={12} tone={colors.brand} dur={2.1} />
      ))}
      {/* the desktop, a folder on its screen */}
      <At x={MON.x} y={BASE} cx>
        <div style={{ transform: 'translateY(-100%)' }}>
          <ClayMonitor w={MON.w} lit={lit(0)} />
        </div>
      </At>
      <At x={MON.x - MON.w / 2 + 12 * ms} y={tops[0] + 27 * ms}>
        <div className="grid place-items-center rounded-[5px] bg-white" style={{ width: 126 * ms, height: 59 * ms }}>
          <div style={fill(0)}>
            <Icon3D name="folder" w={66} shadow={false} />
          </div>
        </div>
      </At>
      {/* the phone, a check badge on it */}
      <At x={PH.x} y={BASE} cx>
        <div style={{ transform: 'translateY(-100%)' }}>
          <ClayPhone w={PH.w} lit={lit(1)} />
        </div>
      </At>
      <At x={PH.x + 24} y={tops[1] + phH * 0.62} cx cy>
        <div className="grid place-items-center rounded-full" style={{ width: 32, height: 32, background: colors.brand, boxShadow: `0 0 0 3px ${colors.white}, 0 8px 16px -8px ${colors.brand}`, ...fill(1) }}>
          <svg width="16" height="16" viewBox="0 0 16 16" aria-hidden>
            <path d="M3 8.5 L6.5 12 L13 4.5" fill="none" stroke="#FFFFFF" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
      </At>
      {/* the laptop, connected users on its screen, a download beside it */}
      <At x={LAP.x} y={BASE} cx>
        <div style={{ transform: 'translateY(-100%)' }}>
          <ClayLaptop w={LAP.w} lit={lit(2)} />
        </div>
      </At>
      <At x={LAP.x - LAP.w / 2 + 26 * ls} y={tops[2] + 12 * ls}>
        <div className="grid place-items-center rounded-[6px] bg-white" style={{ width: 108 * ls, height: 68 * ls }}>
          <div style={fill(2)}>
            <Icon3D name="teamwork" w={86} shadow={false} />
          </div>
        </div>
      </At>
      <At x={LAP.x + 64} y={tops[2] - 18} cx>
        <div style={fill(2)}>
          <Icon3D name="download" w={42} shadow={false} />
        </div>
      </At>
    </>
  )
}

export function Saas({ lesson }: { lesson: string }) {
  return (
    <PointsFigure
      id="saas"
      kicker="SaaS Explained"
      title="Complete Application Delivered"
      lead="Software as a Service delivers a finished application; the provider manages every layer beneath it, leaving the customer only account setup and data"
      lesson={lesson}
      points={['Abstracts the entire stack below the application', 'Provider pushes feature updates automatically, no customer action', 'Representative services: Gmail/Google Workspace, Salesforce, Microsoft 365', 'Customer effort and control both fall sharply toward SaaS']}
      figure={<SaasScene />}
    />
  )
}

/* ================================================================== 32 · order from a restaurant */

const SAAS_IN = 0.36

/**
 * The customer, drawn from the Character Lab (review 2026-10-26: the library render could not take the
 * pizza): the same look as that render, curly dark hair, a blue hoodie, dark jeans.
 */
const PIZZA_BOY: CharacterConfig = {
  name: 'Customer',
  gender: 'male',
  art: 'soft',
  shading: 'clay',
  skinTone: '#F2C29B',
  hair: { style: 'curly', color: '#1B1E2E' },
  face: { jaw: 'round', brows: 'thick', eyes: 'big', mouth: 'full' },
  outfit: { top: 'hoodie', topColor: '#2D63FB', bottom: 'jeans', bottomColor: '#1B2238', shoeColor: '#2A2A30' },
  accessories: {},
  build: { height: 0.9, shoulders: 0.92 },
}
/** the whole figure, with room on the left for the arm that reaches out */
const BOY_CROP = { x0: -30, y0: 10, x1: 360, y1: 595 }
const BOY_S = 0.28
/** the same figure cut at the thighs: a diner behind a table (the cloth hides the cut) */
const SEATED_CROP = { x0: -30, y0: 10, x1: 360, y1: 430 }
/** where the rig's hands are in the held reach, on the lab's canvas (measured): the reaching hand and the hand at the side */
const toStage = (x: number, cx: number, cy: number, floor: number): [number, number] => [x + (cx - BOY_CROP.x0) * BOY_S, floor - (BOY_CROP.y1 - cy) * BOY_S]

/**
 * Review 2026-10-29, the TR's sentence: a restaurant dining room (a panelled
 * wall, a plank floor, the menu board), the kitchen seen through the pass at
 * the back where the chef cooks at the stove, and in front a table laid under
 * a white cloth with the customer seated behind it, the menu open in his
 * hand. The pot steams while the order cooks; at `SAAS_IN` the waiter walks
 * in from the right with the plated meal and sets it on the table, and the
 * menu goes down: chosen and enjoyed, nothing else done by the customer. The
 * cloud side's Application slab lands on the same beat.
 */
function DiningScene() {
  const t = useLoop(AN_LAP, { mode: 'sawtooth', still: 0.62 })
  const fo = fadeOut(t)
  const walk = within(t, SAAS_IN - 0.12, SAAS_IN)
  const hand = within(t, SAAS_IN + 0.02, SAAS_IN + 0.18)
  const served = hand > 0.95
  const cooking = t > 0.04 && t < SAAS_IN
  const TABLE_X = SR.x + 150
  const TABLE_B = S_FLOOR + 6
  const TABLE_TOP = TABLE_B - 41
  const WAITER_X = SR.x + 206
  const HAND = toStage(WAITER_X, 4, 349, S_FLOOR)
  const from: [number, number] = [HAND[0] + (1 - walk) * 90, HAND[1]]
  const to: [number, number] = [TABLE_X + 24, TABLE_TOP - 6]
  const plate = lerp(from, to, hand)
  return (
    <>
      <Room {...SR} kind="hall" />
      {/* the kitchen through the pass: the chef at the stove */}
      <PassWindow x={SR.x + 306} y={SR.y + 8} w={108} h={86}>
        <At x={36} y={82} cx>
          <div style={{ transform: 'translateY(-100%)' }}>
            <Posed cfg={CHEF} props scale={0.13} crop={HALF} expression="happy" />
          </div>
        </At>
        <At x={56} y={78}>
          <div style={{ transform: 'translateY(-100%)' }}>
            <StoveStation w={44} on={cooking} />
          </div>
        </At>
      </PassWindow>
      <At x={SR.x + 16} y={SR.y + 20}>
        <MenuBoard w={60} />
      </At>
      {/* the customer at his table, choosing from the menu until the dish lands */}
      <At x={TABLE_X - 6} y={TABLE_TOP - 58} cx>
        <ChairBack w={62} />
      </At>
      <Stand x={TABLE_X - 6} b={TABLE_TOP + 21}>
        <Posed cfg={PIZZA_BOY} scale={BOY_S} crop={SEATED_CROP} gesture="presentLeft" amplitude={0.7} at={0.9} expression="happy">
          <div className="absolute" style={{ left: 2, top: 76, opacity: served ? 0 : 1, transition: `opacity 420ms ${EASE}` }}>
            <MenuCard w={34} />
          </div>
        </Posed>
      </Stand>
      <Stand x={TABLE_X} b={TABLE_B}>
        <RoundTable w={120} chairs="none" />
      </Stand>
      {/* the waiter, in from the right with the plated meal (a `Stand`, so the figure's box never runs below the stage) */}
      <Stand x={WAITER_X + ((BOY_CROP.x1 - BOY_CROP.x0) * BOY_S) / 2} b={S_FLOOR} style={{ transform: `translateX(${(1 - walk) * 90}px)`, opacity: Math.min(1, walk * 3) * fo }}>
        <Posed cfg={WAITER_CFG} scale={BOY_S} crop={BOY_CROP} gesture="presentLeft" at={0.9} expression="happy" />
      </Stand>
      <At x={plate[0] - 25} y={plate[1] - 12} style={{ opacity: Math.min(1, walk * 3) * fo }}>
        <ClayPizza w={50} stage={3} tray={LAB.lavDeep} />
      </At>
    </>
  )
}

export function SaasAnalogy({ lesson }: { lesson: string }) {
  return (
    <IsoAnalogy
      id="saas-analogy"
      kicker="SaaS Explained"
      lesson={lesson}
      everyday={{ label: 'Order the meal, the restaurant does the rest', scene: <DiningScene /> }}
      text="A ready-made pizza is ordered directly from Domino's with no kitchen work at all, just as the SaaS provider manages the entire stack while the customer only uses the finished application."
      cloud={{ label: 'SaaS', scene: <Stack4 owners={['P', 'P', 'P', 'P']} arrive={[SAAS_IN, SAAS_IN + 0.03, SAAS_IN + 0.06, SAAS_IN + 0.09]} data /> }}
    />
  )
}
